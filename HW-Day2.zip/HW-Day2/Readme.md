# HTML-CSS-HW

you are required to use what we have learned today to recreate this page, don't forget to split your css and html files, use this repo to help you organize your project structure.

## Expected results:


![French Onion](https://i.imgur.com/uepu2DO.jpg)

## Extra Challenge

instead of using the images provided in the images folder, use the icons folder and css to recreate the exact same page with the same layout

## Extra Resources

- [CSS Reference from MDN](https://developer.mozilla.org/en-US/docs/Web/CSS)
- [CSS Background Image](https://developer.mozilla.org/en/docs/Web/CSS/background-image)

**Have Fun with it!**

